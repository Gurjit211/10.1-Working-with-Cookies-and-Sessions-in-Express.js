const express = require('express');
const cookieParser = require('cookie-parser');
const session = require('express-session');
require('dotenv').config();

const app = express();
const port = 3000;

// Middleware
app.use(cookieParser(process.env.COOKIE_SECRET));
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true
}));

// Routes
app.get('/set-cookie', (req, res) => {
  res.cookie('user', 'Gurjit Singh');
  res.send('Cookie set!');
});

app.get('/get-cookie', (req, res) => {
  const user = req.cookies.user;
  res.send(`Cookie retrieved: ${user}`);
});

app.get('/set-signed-cookie', (req, res) => {
  res.cookie('user', 'Signed Gurjit Singh', { signed: true });
  res.send('Signed cookie set!');
});

app.get('/get-signed-cookie', (req, res) => {
  const user = req.signedCookies.user;
  res.send(`Signed cookie retrieved: ${user}`);
});

app.get('/set-session', (req, res) => {
  req.session.user = 'Session Gurjit Singh';
  res.send('Session data set!');
});

app.get('/get-session', (req, res) => {
  const user = req.session.user;
  res.send(`Session data retrieved: ${user}`);
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
